from ASRCAISim1.addons.rayUtility.extension.agents.impala.my_impala import MyImpalaTrainer, DEFAULT_CONFIG

__all__ = ["MyImpalaTrainer", "DEFAULT_CONFIG"]
